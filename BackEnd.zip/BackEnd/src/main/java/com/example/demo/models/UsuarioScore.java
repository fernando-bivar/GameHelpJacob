package com.example.demo.models;

public class UsuarioScore {
	private int tempo;

	public int getTempo() {
		return tempo;
	}

	public void setTempo(int tempo) {
		this.tempo = tempo;
	}
	
}
