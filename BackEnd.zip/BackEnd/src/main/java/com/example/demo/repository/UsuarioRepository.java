package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.example.demo.models.Usuario;

public interface UsuarioRepository extends PagingAndSortingRepository<Usuario, Long>{
	
	@Query(value = "select * from usuario order by tempo asc", nativeQuery = true)
	public List<Usuario> findAllOrderByAsc();
	
	public Usuario findByNick(String nick);
}
