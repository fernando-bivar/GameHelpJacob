package com.example.demo.resources;


//import java.util.HashMap;
import java.util.List;
//import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.Usuario;
import com.example.demo.models.UsuarioLogin;
import com.example.demo.models.UsuarioScore;
import com.example.demo.repository.UsuarioRepository;

@RestController
@RequestMapping(value = "/apiUser")
public class UsuarioResource {
	public String nickSave;
	@Autowired
	UsuarioRepository repositoryUser;
	
	@CrossOrigin
	@GetMapping("/selectUser")
	public List<Usuario> listaUsuarios(){
		
		return (List<Usuario>) repositoryUser.findAllOrderByAsc();
	}
	
	@CrossOrigin
	@PostMapping(value = "/insertUser")
	public boolean create(@RequestBody Usuario user){
		try {
			repositoryUser.save(user);
			return true;
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}
	}
	
	@CrossOrigin
	@PostMapping(value = "/acessUser")
	public boolean loginCompare(@RequestBody UsuarioLogin user1){
		Usuario user = repositoryUser.findByNick(user1.getNick());
		if (user.getSenha().equals(user1.getSenha())) {
			nickSave = user.getNick();
			return true;
		} else {
			return false;
		}
	}
	
	@CrossOrigin
	@PostMapping(value = "/scoreUser")
	public boolean addScore(@RequestBody UsuarioScore user1){
			Usuario user = repositoryUser.findByNick(nickSave);
			if (user.getTempo() > user1.getTempo()) {
				user.setTempo(user1.getTempo());
				repositoryUser.save(user);
				return true;
			} else {
				return false;
			}
			
		
	}
}
